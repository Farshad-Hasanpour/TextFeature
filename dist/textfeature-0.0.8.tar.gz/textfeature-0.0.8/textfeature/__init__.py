from . import module
TextFeature = module.TextFeature
